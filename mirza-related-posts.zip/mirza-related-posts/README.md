# mirza-related-posts
An ajax based related posts plug-in for wordpress.
