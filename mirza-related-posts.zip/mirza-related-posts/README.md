# Mirza Related Posts - MRP v1.0
An ajax based related posts plug-in for wordpress. Simple, fast and secure :)

For install download zip file from here:

https://github.com/mirzazeyrek/mirza-related-posts/blob/master/mirza-related-posts.zip

Go to plug-ins -> add new -> upload plugin and choose downloaded zip file.
