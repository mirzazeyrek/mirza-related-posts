=== Plugin Name ===
Contributors: Ugur Mirza Zeyrek
Tags: related posts,related post
Plugin URI: https://github.com/mirzazeyrek/mirza-related-posts
Author URI: http://mirzazeyrek.wordpress.com
Author: mirza
Requires at least: 4.4
Tested up to: 4.6.1
Stable tag: 1.0
Version: 1.0
License: GPLv2

Ajax based related posts plug-in

== Description ==
Mirza Related Posts Plug-in shows related articles via ajax based system.
MRP brings last 3 posts in same category with thumbnail image, title and 150 characters preview text from content.

<blockquote>
  Support only <a href="https://github.com/mirzazeyrek/mirza-related-posts/issues" target="_blank">HERE</a><br />
  <p>MRP only works with PHP 5.6+ or higher and WordPress 4.4+</p>
</blockquote>